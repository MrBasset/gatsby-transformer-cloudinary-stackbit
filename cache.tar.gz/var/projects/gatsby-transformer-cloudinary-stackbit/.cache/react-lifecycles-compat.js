exports.polyfill = Component => Component
